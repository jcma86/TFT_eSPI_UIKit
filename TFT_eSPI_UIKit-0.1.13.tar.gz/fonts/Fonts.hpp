#ifndef __UIKIT_FONTS__
#define __UIKIT_FONTS__

#include <TFT_eSPI.h>

#include "IBMPlexMono-Regular6pt8b.h"
#include "IBMPlexMono-Regular8pt8b.h"
#include "IBMPlexMono-Medium8pt8b.h"
#include "IBMPlexMono-Bold8pt8b.h"

#include "SourceCodePro-Regular8pt8b.h"
#include "SourceCodePro-Regular10pt8b.h"
#include "SourceCodePro-Regular-20.h"

#include "FragmentMono-Regular-16.h"
#include "FragmentMono-Regular-20.h"

#endif