#ifndef __UIKIT_BUTTONS_STEPPER_STYLE__
#define __UIKIT_BUTTONS_STEPPER_STYLE__

#include "../../fonts/SourceCodePro-Bold9.h"

#define STEPPER_FONT_FAMILY &SourceCodePro_Bold9pt7b

#endif