#ifndef __UIKIT_FONTS__
#define __UIKIT_FONTS__

#include "IBMPlexMono-Regular6pt8b.h"

#include "Orbitron-Regular10.h"
#include "Orbitron-Regular14.h"

#include "OpenSans-Regular14.h"

#include "KdamThmorPro-Regular14.h"

#include "SourceCodePro-Medium8.h"
#include "SourceCodePro-Bold9.h"

#include "SevenSegment14.h"
#include "SevenSegment32.h"

#endif