#ifndef __UIKIT_DISPLAY_LABEL_STYLE__
#define __UIKIT_DISPLAY_LABEL_STYLE__

#include "../../fonts/Fonts.hpp"
#include "../../helpers/Colors.hpp"

#define LABEL_FONT_FAMILY &Orbitron_Regular10pt7b
#define LABEL_FONT_SCALE 1
#define LABEL_FONT_COLOR COLOR_BLACK

#endif
