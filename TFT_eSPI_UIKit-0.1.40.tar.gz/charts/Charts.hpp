#ifndef __UIKIT_CHARTS__
#define __UIKIT_CHARTS__

class Charts
{
};

#endif
