#ifndef __UIKIT_FONTS__
#define __UIKIT_FONTS__

#include <TFT_eSPI.h>

#include "IBMPlexMono-Regular6pt8b.h"

#include "LiberationMono-Regular14.h"
#include "LiberationMono-Regular16.h"
#include "LiberationMono-Regular18.h"
#include "LiberationMono-Regular22.h"
#include "LiberationMono-Regular28.h"

#include "OpenSans-Regular14.h"

#include "Poppins-Regular14.h"

#include "KdamThmorPro-Regular14.h"
#include "KdamThmorPro-Regular16.h"

#include "SevenSegment14.h"
#include "SevenSegment32.h"

#endif